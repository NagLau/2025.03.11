import React from "react";
import "./App.css";

function App() {
  return (
    <>
      <head>
        <meta charSet="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css" />
        <link rel="stylesheet" href="style.css" />
        <title>DriveUs</title>
      </head>
      <body>
        <header>
          <h1 id="focim">DriveUs</h1>
          <nav>
            <a href="../hirlap/hirlap.html">HÍRLAP</a>
            <a href="../autok/autok.html">AUTÓK</a>
            <a href="../berleseim/berleseim.html">BÉRLÉSEIM</a>
            <a href="../profilom/profilom.html">PROFILOM</a>
          </nav>
          <div id="google_translate_element"></div>
        </header>
        <main>
          <section className="intro">
            <h1>DriveUs - A szabadság, ami mindig úton van.</h1>
            <p>
              Üdvözöljük a DriveUs autóbérlő weboldalán! Mi segítünk Önnek
              abban, hogy minden utazás egy felejthetetlen élmény legyen...
            </p>
          </section>
          <section className="card-container">
            {[
              {
                title: "Rugalmas bérlés",
                text: "Rövid és hosszú távú autóbérlés egyaránt elérhető...",
              },
              {
                title: "Széles választék",
                text: "A legújabb modellek és különféle típusok...",
              },
              {
                title: "Kiváló állapotú autók",
                text: "Minden járművet rendszeresen karbantartunk...",
              },
              {
                title: "Versenyképes árak",
                text: "Szolgáltatásainkhoz rendkívül versenyképes árakat kínálunk...",
              },
              {
                title: "24/7 Ügyfélszolgálat",
                text: "Ha bármilyen kérdése lenne, a nap 24 órájában elérhető ügyfélszolgálatunk...",
              },
            ].map((item, index) => (
              <div className="card" key={index}>
                <h4>{item.title}</h4>
                <p>{item.text}</p>
              </div>
            ))}
          </section>
          <div className="row">
            <div className="col-6">
              <div className="gallery-container">
                <button className="prev" onClick={() => moveSlide(-1)}>
                  &#10094;
                </button>
                <div className="gallery">
                  {[
                    "../logo.jpg",
                    "luxus.jpg",
                    "hetkoznapi.jpg",
                    "sport.jpg",
                    "bkep1.jpg",
                    "bkep2.jpg",
                    "bkep3.jpg",
                    "bkep4.png",
                    "bkep5.png",
                  ].map((src, index) => (
                    <img key={index} src={src} alt={`Kép ${index + 1}`} />
                  ))}
                </div>
                <button className="next" onClick={() => moveSlide(1)}>
                  &#10095;
                </button>
              </div>
            </div>
            <div className="col-6">
              <div>
                <p id="pp">
                  Az utazás nem csupán az úti célról szól, hanem magáról az
                  élményről is...
                </p>
                <button
                  id="foglalj"
                  className="book-now"
                  onClick={() => (window.location.href = "../autok/autok.html")}
                >
                  FOGLALJ MOST!
                </button>
              </div>
            </div>
          </div>
        </main>
        <footer>
          <img src="../logo.jpg" alt="DriveUs Logo" id="footer-img" />
          <p id="footer_p">
            Válogass prémium autóink közül, és indulj útnak stílusosan!
          </p>
        </footer>
        <script src="script.js"></script>
      </body>
    </>
  );
}

export default App;
